using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Feeds.Interop;

namespace RSS_Sample_Application
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Please note if the url to the feed already exisits anywhere in the feeds folder 
            //an exception will occur.

            //Add a feed called "windowscoding.com" to the root feeds folder.
            if (AddIE7Feed("", "http://windowscoding.com/blogs/MainFeed.aspx", "windowscoding.com"))
            {
                MessageBox.Show("Feed was added successfully");
            }
            else
            {
                MessageBox.Show("Failed to add the Feed");
            }
            //close the application.
            this.Close();
        }

        private bool AddIE7Feed(string folder, string url, string title)
        {
            #region 'Naming Constraints'
            /*           
             * http://msdn.microsoft.com/library/default.asp?url=/library/en-us/feedsapi/rss/overviews/name_ovw.asp
             * To allow a wider variety of feed and folder names, some characters that are disallowed by the file system are 
             * remapped using a "tilde" encoding scheme where possible. Encoding introduces additional characters into the 
             * name, which can decrease the total possible length of the name. 
             * 
             * The Windows RSS Platform imposes the following constraints on feed and folder names:
             * 
             * You may use any character in the current code page for a feed or folder name�including Unicode characters�except 
             * control characters in the range of 0 (zero) through 31. If a method is called with a name that contains one or 
             * more of these characters then the method will fail.
             * 
             * Feed and folder names are limited to 120 characters in length. (This allows the encoded name to be up to 240 
             * characters.) If a method is called with a feed name longer then 120 chars then the method will fail an 
             * HRESULT derived from the Microsoft Win32 ERROR_INVALID_NAME error.
             * 
             * The empty string (string of zero length) is an invalid name.
             * 
             * The backslash (\) is reserved for use as a path separator and may not be used as part of a feed or folder name.
             * It is valid only as part of a path.
            */

            if (title == string.Empty)
            {
                return false;
            }

            title = title.Replace('\\', '-');

            if (folder.Length > 120)
            {
                folder = folder.Remove(117) + "...";
            }
            if (title.Length > 120)
            {
                title = title.Remove(117) + "...";
            }
            #endregion

            FeedsManager fm = new FeedsManager();
            IFeedFolder rootFolder = (IFeedFolder)fm.RootFolder;
            IFeedFolder subFolder = rootFolder;

            try
            {
                //if a folderpath is supplied the following code is executed.
                if (folder != string.Empty)
                {
                    //checks to see if the folder exists.
                    if (!rootFolder.ExistsSubfolder(folder))
                    {
                        //creates the folder if it does not exist.
                        rootFolder.CreateSubfolder(folder);
                        //set the subFolder to the new folder.
                        subFolder = (IFeedFolder)rootFolder.GetSubfolder(folder);
                    }
                }
                //checks to see if the feed exists (by checking the url and title). 
                if (!subFolder.ExistsFeed(title) && !fm.IsSubscribed(url))
                {
                    //creates the feed if it does not exist
                    subFolder.CreateFeed(title, url);
                    return true;
                }
                return false;
            }
            //catches any Exception that may be thrown.
            catch (Exception)
            {
                return false;
            }
        }
    }
}