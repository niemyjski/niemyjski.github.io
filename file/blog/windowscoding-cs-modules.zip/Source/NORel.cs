// ----------------------------------------------------------------------
// Name: Community Server 2.1 NORelModule
// Author: Blake Niemyjski
// Date: January 8th, 2007
// Version: 1.0.0.0
// Questions: private message me at http://windowscoding.com/blogs/blake/default.aspx
// ----------------------------------------------------------------------

#region Copyright � 2006-2007 windowscoding.com

// ----------------------------------------------------------------------

// Redistribution and use in source and binary forms, with or without modification, are permitted
// provided that the following conditions are met:

// Redistributions of source code must retain the above copyright notice, this list of conditions 
// and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice,
// this list of conditions and the following disclaimer in the documentation and/or other materials provided
// with the distribution. 

// Neither the name of Blake Niemyjski, windowscoding, Community Server nor the names of its contributors may
// be used to endorse or promote products derived from this software without specific prior written permission. 

// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
// WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
// PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY 
// DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
// CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
// OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// ----------------------------------------------------------------------
#endregion

using System;
using System.Text;
using System.Xml;
using CommunityServer;
using CommunityServer.Components;

namespace WindowsCoding.CS.Modules
{
    public class NORelModule : ICSModule
    {
        // Stores websites url into siteName.
        private string siteName = "localhost";

        #region ICSModule Members

        public void Init(CSApplication csa, System.Xml.XmlNode node)
        {
            // Link below lists all the global events that your 
            // application can process.
            // http://developer.communityserver.org/default.aspx/CS.CSApplication

            // Event raised before an individual post is rendered.
            csa.PreRenderPost += new CSPostEventHandler(csa_PreRenderPost);

            // Fires before a User is saved/updated to the data store.
            csa.PreUserUpdate += new CSUserEventHandler(csa_UserEventHandler);

            //Read settings from communityserver.config CSModules section.
            if (node != null)
            {
                XmlAttribute attribute = node.Attributes["sitename"];
                if (attribute != null)
                {
                    // If attribute is not empty then change value from localhost
                    // to value stored in communityserver.config.
                    siteName = attribute.Value.ToLower();
                }
            }
        }
        #endregion

        //Fires before a User is saved/updated to the data store.
        private void csa_UserEventHandler(User user, CSEventArgs e)
        {
            if (e.State == ObjectState.Update)
            {
                user.Profile.Bio = ReplaceHrefAttributes(user.Profile.Bio);
                user.Profile.Signature = ReplaceHrefAttributes(user.Profile.Signature);
                user.Profile.CommonName = ReplaceHrefAttributes(user.Profile.CommonName);
                user.Profile.Location = ReplaceHrefAttributes(user.Profile.Location);
                user.Profile.Occupation = ReplaceHrefAttributes(user.Profile.Occupation);
                user.Profile.Interests = ReplaceHrefAttributes(user.Profile.Interests);
                user.Profile.WebAddress = ReplaceHrefAttributes(user.Profile.WebAddress);
                user.Profile.WebGallery = ReplaceHrefAttributes(user.Profile.WebGallery);
                user.Profile.WebLog = ReplaceHrefAttributes(user.Profile.WebLog);
            }
        }

        // Event raised before an individual post is rendered
        private void csa_PreRenderPost(IContent content, CSPostEventArgs e)
        {
            if (e.ApplicationType != ApplicationType.Forum)
            {
                // Updates content.FormattedBody's html with adequate
                // rel="nofollow" Attributes.
                content.FormattedBody = ReplaceHrefAttributes(content.Body);
            }
        }

        // Method that updates an documents links attributes.
        private string ReplaceHrefAttributes(string body)
        {
            if (body.Contains("</a>"))
            {
                // Declare variables
                string[] strSplitSeparators = { "<a ", "</a>" };
                string[] strBodyArray;

                // Splits the string body by html link elements as defined in strSplitSeparators.
                // Before Split a link would appear as follows: (<a href="http://windowscoding.com">windowscoding</a>)
                // After split a link looks like this: (href="http://windowscoding.com">windowscoding)
                strBodyArray = body.Split(strSplitSeparators, System.StringSplitOptions.RemoveEmptyEntries);

                // Stores the updated string body.
                StringBuilder strTempContent = new StringBuilder(String.Empty);

                // Loops through each Body Array element.
                for (int accumulator = 0; accumulator < strBodyArray.Length; accumulator++)
                {
                    // Temp string used for readability
                    string temp = strBodyArray[accumulator].ToLower();

                    // Checks link to see if it has a valid link.
                    if (temp.Contains("href=\""))
                    {
                        // Checks link to see if it is associated with an anchor tag.
                        if (!temp.Contains("name=\"") && !temp.Contains("href=\"#"))
                        {
                            // Call Validate link to return updated link.
                            strTempContent.Append(ValidateLink(strBodyArray[accumulator]));
                        }
                    }
                    else
                    {
                        // Updates temp string because it is not an HTML link.
                        strTempContent.Append(strBodyArray[accumulator]);
                    }
                }
                // Return updated temporary string.
                return strTempContent.ToString();
            }
            // Return unmodified body, if it does not contain a link.
            return body;
        }

        private string ValidateLink(string href)
        {
            // Declare variables
            string[] strSplitSeparators = { ">" };
            string[] strHrefArray = { String.Empty, String.Empty };

            // Splits the html link in two parts as defined in strSplitSeparators.
            // Before processing href looked like: (href="http://windowscoding.com">windowscoding)
            // After processing href, strHrefArray looks as follows:
            // strHrefArray[0] = (href="http://windowscoding.com")
            // strHrefArray[1] = (windowscoding)
            strHrefArray = href.Split(strSplitSeparators, 2, System.StringSplitOptions.None);

            // Checks a links contents to make sure its valid, checks for:
            // (<a href="http://windowscoding.com"></a>)
            if (String.IsNullOrEmpty(strHrefArray[1]))
            {
                //(<a href="http://windowscoding.com">Invalid URL</a>)
                strHrefArray[1] = "Invalid URL";
            }

            // Temp string is used to make code more readable.
            string temp = strHrefArray[0].ToLower();

            // If link is an external link then the link is not processed.
            if (!temp.Contains(siteName) && !temp.Contains("href=\"/") && !temp.Contains("href=\"."))
            {
                //if rel="nofollow" attribute already exists then don't add it.
                if (!temp.Contains("nofollow"))
                {
                    //return link with added rel="nofollow" attribute.
                    return String.Format("<a {0} rel=\"nofollow\">{1}</a>", strHrefArray[0], strHrefArray[1]);
                }
            }
            //return the link.
            return String.Format("<a {0}>{1}</a>", strHrefArray[0], strHrefArray[1]);
        }
    }
}